# Med School Study Planner

A complexity-aware, fairness-constrained scheduling engine for medical students. The first release deliberately uses an interpretable rule-based model; optimization and predictive learning can be added after usage data exists.

## Architecture

```text
Curriculum + Exams + Performance
              |
              v
       Priority scoring
   urgency / complexity /
 mastery gap / exam weight /
        review need
              |
              v
      Fairness allocator
   subject floors -> weighted
      remainder allocation
              |
              v
        StudySession plan
       daily + weekly horizon
              |
              v
       actual time + quiz
          performance
              |
              v
      mastery / review date /
        effort recalibration
```

### Tier 1 in this repository

- **Complexity:** supports cognitive-load type, volume, self-rating, and historical time-to-mastery signals, with a fallback complexity score.
- **Priority:** interpretable weighted score combining urgency, complexity, mastery gap, exam weight, and review need.
- **Balance:** every active subject receives a configurable fairness floor before the remaining capacity is allocated by priority.
- **Spaced repetition:** deterministic SM-2-inspired interval update with reset/expansion behavior.
- **Wellbeing:** daily hour ceiling and hard rest-day exclusion.
- **Adaptation:** completed sessions update mastery, next review date, and estimated effort.

## Local development

```bash
python -m pip install -e ".[dev]"
pytest -q
uvicorn study_planner.api.main:app --reload
```

Then open `http://127.0.0.1:8000/docs` for the interactive API docs.

## API

`GET /health`

`POST /v1/schedule`

Example request:

```json
{
  "start_date": "2026-08-20",
  "horizon_days": 7,
  "subjects": [
    {"id": "anat", "name": "Anatomy", "exam_weight": 0.9},
    {"id": "pharm", "name": "Pharmacology", "exam_weight": 0.8}
  ],
  "topics": [
    {"id": "anat1", "subject_id": "anat", "name": "Thorax", "complexity_score": 0.8, "mastery": 0.25},
    {"id": "ph1", "subject_id": "pharm", "name": "Autonomics", "complexity_score": 0.7, "mastery": 0.4}
  ],
  "exams": [
    {"id": "midterm", "date": "2026-08-29", "subject_ids": ["anat", "pharm"]}
  ],
  "profile": {
    "daily_available_hours": 4,
    "rest_days": [4],
    "review_reserve_ratio": 0.25,
    "session_minutes": 50,
    "fairness_floor_ratio": 0.15,
    "max_sessions_per_day": 6
  }
}
```

## Roadmap

1. **Tier 1:** scheduling engine + API + tests (current).
2. **Tier 2:** OR-Tools/PuLP constrained optimization, especially for exam collisions and explicit must-finish constraints.
3. **Tier 3:** empirical learning curves from actual-vs-planned time and quiz performance.
4. Persistent PostgreSQL storage, authentication, calendar UI, analytics, and deployment.

The engine is intentionally isolated from the API so the scheduling core can be tested, benchmarked, and replaced without rewriting the product layer.
