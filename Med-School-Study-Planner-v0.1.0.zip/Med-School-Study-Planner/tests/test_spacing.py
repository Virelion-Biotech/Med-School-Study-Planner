from datetime import date

from study_planner.spaced_repetition import next_review_date


def test_failed_review_resets_interval():
    assert next_review_date(date(2026, 8, 20), 0.4, 10).isoformat() == "2026-08-21"


def test_strong_review_expands_interval():
    assert next_review_date(date(2026, 8, 20), 0.9, 4).isoformat() == "2026-08-30"
