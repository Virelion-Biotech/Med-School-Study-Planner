from datetime import date

from study_planner.models import Exam, Topic
from study_planner.scoring import days_to_exam, priority_score


def test_exam_urgency_increases_as_exam_approaches():
    topic = Topic(id="t1", subject_id="s1", name="Cardio", mastery=0.2)
    exam = Exam(id="e1", date=date(2026, 8, 30), subject_ids=["s1"])
    near, _ = priority_score(topic, [exam], date(2026, 8, 29))
    far, _ = priority_score(topic, [exam], date(2026, 8, 20))
    assert near > far
    assert days_to_exam(topic, [exam], date(2026, 8, 20)) == 10


def test_complexity_and_mastery_gap_raise_priority():
    low = Topic(id="low", subject_id="s", name="Low", complexity_score=0.1, mastery=0.95)
    high = Topic(id="high", subject_id="s", name="High", complexity_score=0.9, mastery=0.1)
    score_low, _ = priority_score(low, [], date.today())
    score_high, _ = priority_score(high, [], date.today())
    assert score_high > score_low
