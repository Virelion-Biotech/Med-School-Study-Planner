from collections import defaultdict
from datetime import date

from study_planner.allocator import allocate
from study_planner.models import Subject, Topic, UserProfile


def test_fairness_floor_prevents_subject_starvation():
    subjects = [Subject("a", "Anatomy"), Subject("b", "Biochem"), Subject("c", "Pharm")]
    topics = [
        Topic("a1", "a", "High yield anatomy", complexity_score=0.9, mastery=0.0),
        Topic("b1", "b", "Biochem", complexity_score=0.2, mastery=0.9),
        Topic("c1", "c", "Pharm", complexity_score=0.2, mastery=0.9),
    ]
    profile = UserProfile(daily_available_hours=3, session_minutes=50, fairness_floor_ratio=0.2)
    sessions = allocate(date(2026, 8, 20), 7, subjects, topics, [], profile)
    minutes = defaultdict(int)
    for session in sessions:
        minutes[session.subject_id] += session.planned_minutes
    assert all(minutes[s.id] > 0 for s in subjects)


def test_rest_day_is_empty():
    subjects = [Subject("a", "Anatomy")]
    topics = [Topic("a1", "a", "Topic", complexity_score=0.7)]
    # 2026-08-20 is Thursday (weekday=3).
    profile = UserProfile(daily_available_hours=3, rest_days={3})
    sessions = allocate(date(2026, 8, 20), 1, subjects, topics, [], profile)
    assert sessions == []
