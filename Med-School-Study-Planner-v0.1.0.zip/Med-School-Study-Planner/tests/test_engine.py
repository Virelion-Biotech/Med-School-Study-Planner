from datetime import date

from study_planner.engine import SchedulingEngine
from study_planner.models import SchedulingRequest, Subject, Topic, UserProfile


def test_performance_updates_mastery_and_review_date():
    topic = Topic("t", "s", "Topic", mastery=0.1, estimated_hours=2)
    updated = SchedulingEngine().record_performance(topic, date(2026, 8, 20), 0.9, 50, 4)
    assert updated.mastery > 0.1
    assert updated.next_review_due == date(2026, 8, 30)
    assert updated.estimated_hours < 2


def test_engine_generates_sessions():
    request = SchedulingRequest(
        start_date=date(2026, 8, 20),
        horizon_days=2,
        subjects=[Subject("s", "Cardio")],
        topics=[Topic("t", "s", "Hemodynamics", mastery=0.2)],
        profile=UserProfile(daily_available_hours=2, session_minutes=50),
    )
    sessions = SchedulingEngine().generate(request)
    assert sessions
    assert all(s.topic_id == "t" for s in sessions)
