from __future__ import annotations

from datetime import date

from .models import Exam, Topic


def days_to_exam(topic: Topic, exams: list[Exam], on_date: date) -> int | None:
    relevant = [
        e for e in exams
        if topic.id in e.topic_ids or (not e.topic_ids and topic.subject_id in e.subject_ids)
    ]
    if not relevant:
        return None
    future = [max((e.date - on_date).days, 0) for e in relevant]
    return min(future) if future else None


def urgency(days: int | None) -> float:
    if days is None:
        return 0.15
    if days <= 0:
        return 1.0
    return min(1.0, 1.0 / (days / 2.0 + 1.0))


def review_need(topic: Topic, on_date: date) -> float:
    if topic.next_review_due is None:
        return 0.0
    delta = (on_date - topic.next_review_due).days
    if delta >= 0:
        return min(1.0, 0.6 + 0.1 * min(delta, 4))
    return max(0.0, 0.6 + delta / 10.0)


def priority_score(
    topic: Topic, exams: list[Exam], on_date: date, subject_exam_weight: float = 1.0
) -> tuple[float, list[str]]:
    reasons: list[str] = []
    days = days_to_exam(topic, exams, on_date)
    u = urgency(days)
    c = topic.effective_complexity()
    gap = topic.mastery_gap()
    exam_weight = min(max(topic.exam_weight, 0.0), 1.0) * min(max(subject_exam_weight, 0.0), 1.0)
    review = review_need(topic, on_date)

    if days is not None and days <= 7:
        reasons.append(f"exam in {days}d")
    if c >= 0.7:
        reasons.append("high complexity")
    if gap >= 0.5:
        reasons.append("large mastery gap")
    if review >= 0.6:
        reasons.append("review due")

    # Interpretable Tier-1 formula. Weights sum to 1.0.
    score = 0.35 * u + 0.20 * c + 0.25 * gap + 0.10 * exam_weight + 0.10 * review
    return round(score, 6), reasons
