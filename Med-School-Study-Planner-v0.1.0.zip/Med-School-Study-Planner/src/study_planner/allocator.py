from __future__ import annotations

from collections import defaultdict
from datetime import date, timedelta

from .models import SessionType, StudySession, Subject, Topic, UserProfile
from .scoring import priority_score


def _daily_capacity(profile: UserProfile, day: date) -> int:
    if day.weekday() in profile.rest_days:
        return 0
    return max(0, round(profile.daily_available_hours * 60))


def _review_reserve(profile: UserProfile, day: date, horizon_end: date, nearest_exam_days: int | None) -> float:
    reserve = min(max(profile.review_reserve_ratio, 0.0), 0.8)
    if nearest_exam_days is not None and nearest_exam_days <= 14:
        reserve += 0.10
    if nearest_exam_days is not None and nearest_exam_days <= 7:
        reserve += 0.10
    return min(reserve, 0.85)


def allocate(
    start_date: date,
    horizon_days: int,
    subjects: list[Subject],
    topics: list[Topic],
    exams: list,
    profile: UserProfile,
) -> list[StudySession]:
    active_subjects = [s for s in subjects if s.active]
    subject_by_id = {s.id: s for s in active_subjects}
    active_topics = [t for t in topics if t.active and t.subject_id in subject_by_id]
    if not active_topics or not active_subjects or horizon_days <= 0:
        return []

    horizon_end = start_date + timedelta(days=horizon_days - 1)
    weekly_capacity = sum(_daily_capacity(profile, start_date + timedelta(days=i)) for i in range(horizon_days))
    custom_floors = {s.id: s.weekly_min_minutes for s in active_subjects if s.weekly_min_minutes is not None}
    fairness_ratio = min(max(profile.fairness_floor_ratio, 0.0), 0.8)
    default_floor = int(min(weekly_capacity / len(active_subjects), weekly_capacity * fairness_ratio))
    floors = {s.id: custom_floors.get(s.id, default_floor) for s in active_subjects}

    allocated = defaultdict(int)
    sessions: list[StudySession] = []
    remaining_hours = {t.id: max(0.25, t.estimated_hours) * 60 for t in active_topics}

    for offset in range(horizon_days):
        day = start_date + timedelta(days=offset)
        capacity = _daily_capacity(profile, day)
        if capacity <= 0:
            continue

        today_used = 0
        while today_used + profile.session_minutes <= capacity and len([x for x in sessions if x.date == day]) < profile.max_sessions_per_day:
            scored: list[tuple[float, Topic, list[str]]] = []
            for topic in active_topics:
                if remaining_hours[topic.id] <= 0:
                    continue
                score, reasons = priority_score(topic, exams, day, subject_by_id[topic.subject_id].exam_weight)
                if allocated[topic.subject_id] < floors[topic.subject_id]:
                    score += 1.5
                    reasons = [*reasons, "fairness floor"]
                scored.append((score, topic, reasons))
            if not scored:
                break

            scored.sort(key=lambda item: (-item[0], item[1].id))
            capacity_left = capacity - today_used
            chunk = min(profile.session_minutes, capacity_left)
            score, topic, reasons = scored[0]
            nearest_exam_days = None
            for exam in exams:
                if topic.id in exam.topic_ids or (not exam.topic_ids and topic.subject_id in exam.subject_ids):
                    days = max(0, (exam.date - day).days)
                    nearest_exam_days = days if nearest_exam_days is None else min(nearest_exam_days, days)
            reserve = _review_reserve(profile, day, horizon_end, nearest_exam_days)
            review_due_topics = [t for t in active_topics if t.next_review_due is not None and t.next_review_due <= day and remaining_hours[t.id] > 0]
            if review_due_topics and (today_used / capacity) < reserve:
                review_scored = []
                for review_topic in review_due_topics:
                    review_score, review_reasons = priority_score(review_topic, exams, day, subject_by_id[review_topic.subject_id].exam_weight)
                    review_scored.append((review_score, review_topic, [*review_reasons, "review reserve"]))
                review_scored.sort(key=lambda item: (-item[0], item[1].id))
                score, topic, reasons = review_scored[0]
                session_type = SessionType.REVIEW
            else:
                session_type = SessionType.NEW
            if topic.mastery >= 0.75 and session_type == SessionType.NEW:
                session_type = SessionType.PRACTICE

            sessions.append(StudySession(
                date=day,
                topic_id=topic.id,
                subject_id=topic.subject_id,
                planned_minutes=chunk,
                session_type=session_type,
                priority_score=score,
                rationale=reasons,
            ))
            allocated[topic.subject_id] += chunk
            remaining_hours[topic.id] -= chunk
            today_used += chunk

    return sessions
