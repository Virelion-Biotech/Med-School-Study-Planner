"""Core package for the Med School Study Planner."""

from .engine import SchedulingEngine

__all__ = ["SchedulingEngine"]
