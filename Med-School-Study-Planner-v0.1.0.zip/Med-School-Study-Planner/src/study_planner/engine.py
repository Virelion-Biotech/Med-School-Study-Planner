from __future__ import annotations

from datetime import date

from .allocator import allocate
from .models import SchedulingRequest, StudySession, Topic
from .spaced_repetition import next_review_date


class SchedulingEngine:
    """Orchestrates interpretable planning + adaptive feedback updates."""

    def generate(self, request: SchedulingRequest) -> list[StudySession]:
        return allocate(
            start_date=request.start_date,
            horizon_days=request.horizon_days,
            subjects=request.subjects,
            topics=request.topics,
            exams=request.exams,
            profile=request.profile,
        )

    def record_performance(
        self,
        topic: Topic,
        session_date: date,
        performance: float,
        actual_minutes: int,
        current_interval_days: int = 1,
    ) -> Topic:
        """Apply a completed-session result to topic state in-place and return it."""
        score = min(max(performance, 0.0), 1.0)
        minutes = max(actual_minutes, 1)
        # Small learning update now; future versions can replace this with a fitted curve.
        learning_gain = min(0.15, 0.03 + 0.04 * score * min(minutes / 50.0, 2.0))
        topic.mastery = round(min(1.0, topic.mastery + learning_gain), 4)
        topic.last_studied = session_date
        topic.next_review_due = next_review_date(session_date, score, current_interval_days)
        # Reconcile estimated effort using the observed time, bounded to avoid wild swings.
        target_hours = max(0.25, topic.estimated_hours)
        observed_hours = minutes / 60.0
        topic.estimated_hours = round(0.7 * target_hours + 0.3 * observed_hours, 3)
        return topic
