from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date
from enum import Enum


class CognitiveLoad(str, Enum):
    ROTE = "rote"
    CONCEPTUAL = "conceptual"
    CLINICAL = "clinical"
    MIXED = "mixed"


class SessionType(str, Enum):
    NEW = "new"
    REVIEW = "review"
    PRACTICE = "practice"


@dataclass(frozen=True)
class ComplexitySignals:
    cognitive_load: CognitiveLoad = CognitiveLoad.MIXED
    volume: float = 0.5
    self_rating: float = 3.0
    historical_time_to_mastery: float | None = None

    def normalized(self) -> float:
        load = {
            CognitiveLoad.ROTE: 0.45,
            CognitiveLoad.CONCEPTUAL: 0.70,
            CognitiveLoad.CLINICAL: 0.85,
            CognitiveLoad.MIXED: 0.65,
        }[self.cognitive_load]
        volume = min(max(self.volume, 0.0), 1.0)
        self_rating = (min(max(self.self_rating, 1.0), 5.0) - 1.0) / 4.0
        base = 0.35 * load + 0.30 * volume + 0.20 * self_rating
        if self.historical_time_to_mastery is not None:
            # 4 hours is a deliberately conservative reference point; real data
            # can progressively dominate the subjective estimate as it accumulates.
            historical = min(max(self.historical_time_to_mastery / 4.0, 0.0), 1.0)
            base = 0.45 * base + 0.55 * historical
        return round(min(max(base, 0.0), 1.0), 4)


@dataclass
class Subject:
    id: str
    name: str
    exam_weight: float = 1.0
    category: str = "general"
    weekly_min_minutes: int | None = None
    active: bool = True


@dataclass
class Topic:
    id: str
    subject_id: str
    name: str
    complexity_score: float = 0.5
    estimated_hours: float = 2.0
    mastery: float = 0.0
    last_studied: date | None = None
    next_review_due: date | None = None
    complexity_signals: ComplexitySignals | None = None
    exam_weight: float = 1.0
    active: bool = True

    def effective_complexity(self) -> float:
        if self.complexity_signals is None:
            return min(max(self.complexity_score, 0.0), 1.0)
        return self.complexity_signals.normalized()

    def mastery_gap(self) -> float:
        return 1.0 - min(max(self.mastery, 0.0), 1.0)


@dataclass
class Exam:
    id: str
    date: date
    subject_ids: list[str] = field(default_factory=list)
    topic_ids: list[str] = field(default_factory=list)
    weight: float = 1.0


@dataclass
class StudySession:
    date: date
    topic_id: str
    subject_id: str
    planned_minutes: int
    session_type: SessionType
    priority_score: float
    rationale: list[str] = field(default_factory=list)
    actual_minutes: int | None = None
    performance_score: float | None = None


@dataclass
class UserProfile:
    daily_available_hours: float = 4.0
    energy_pattern: dict[str, float] = field(default_factory=lambda: {
        "morning": 1.0,
        "afternoon": 0.9,
        "evening": 0.8,
    })
    rest_days: set[int] = field(default_factory=set)  # Python weekday numbers: Monday=0.
    review_reserve_ratio: float = 0.25
    session_minutes: int = 50
    fairness_floor_ratio: float = 0.15
    max_sessions_per_day: int = 6


@dataclass
class SchedulingRequest:
    start_date: date
    horizon_days: int
    subjects: list[Subject]
    topics: list[Topic]
    exams: list[Exam] = field(default_factory=list)
    profile: UserProfile = field(default_factory=UserProfile)
