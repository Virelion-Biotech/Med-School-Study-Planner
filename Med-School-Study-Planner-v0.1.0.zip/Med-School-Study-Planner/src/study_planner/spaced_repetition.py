from __future__ import annotations

from datetime import date, timedelta


def next_review_date(current: date, performance: float, interval_days: int = 1) -> date:
    """SM-2-inspired lightweight interval update.

    Performance is expected on a 0..1 scale. Poor results reset the interval;
    strong results expand it. The engine intentionally keeps this deterministic
    and interpretable for an MVP.
    """
    score = min(max(performance, 0.0), 1.0)
    interval = max(interval_days, 1)
    if score < 0.6:
        next_interval = 1
    elif score < 0.8:
        next_interval = max(2, round(interval * 1.7))
    else:
        next_interval = max(3, round(interval * 2.5))
    return current + timedelta(days=next_interval)
