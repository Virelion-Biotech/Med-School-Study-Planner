from __future__ import annotations

from fastapi import FastAPI

from ..engine import SchedulingEngine
from ..models import Exam, SchedulingRequest, Subject, Topic, UserProfile
from .schemas import ScheduleRequest

app = FastAPI(title="Med School Study Planner", version="0.1.0")
engine = SchedulingEngine()


@app.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok"}


@app.post("/v1/schedule")
def generate_schedule(payload: ScheduleRequest) -> dict:
    request = SchedulingRequest(
        start_date=payload.start_date,
        horizon_days=payload.horizon_days,
        subjects=[Subject(**s.model_dump()) for s in payload.subjects],
        topics=[Topic(**t.model_dump()) for t in payload.topics],
        exams=[Exam(**e.model_dump()) for e in payload.exams],
        profile=UserProfile(
            daily_available_hours=payload.profile.daily_available_hours,
            rest_days=set(payload.profile.rest_days),
            review_reserve_ratio=payload.profile.review_reserve_ratio,
            session_minutes=payload.profile.session_minutes,
            fairness_floor_ratio=payload.profile.fairness_floor_ratio,
            max_sessions_per_day=payload.profile.max_sessions_per_day,
        ),
    )
    sessions = engine.generate(request)
    return {
        "sessions": [
            {
                "date": s.date,
                "topic_id": s.topic_id,
                "subject_id": s.subject_id,
                "planned_minutes": s.planned_minutes,
                "session_type": s.session_type,
                "priority_score": s.priority_score,
                "rationale": s.rationale,
            }
            for s in sessions
        ]
    }
