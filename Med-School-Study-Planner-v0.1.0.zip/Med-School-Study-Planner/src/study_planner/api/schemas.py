from __future__ import annotations

from datetime import date
from pydantic import BaseModel, Field


class SubjectIn(BaseModel):
    id: str
    name: str
    exam_weight: float = Field(1.0, ge=0)
    category: str = "general"
    weekly_min_minutes: int | None = Field(None, ge=0)


class TopicIn(BaseModel):
    id: str
    subject_id: str
    name: str
    complexity_score: float = Field(0.5, ge=0, le=1)
    estimated_hours: float = Field(2.0, gt=0)
    mastery: float = Field(0.0, ge=0, le=1)
    last_studied: date | None = None
    next_review_due: date | None = None
    exam_weight: float = Field(1.0, ge=0, le=1)


class ExamIn(BaseModel):
    id: str
    date: date
    subject_ids: list[str] = []
    topic_ids: list[str] = []
    weight: float = Field(1.0, gt=0)


class ProfileIn(BaseModel):
    daily_available_hours: float = Field(4.0, ge=0, le=24)
    rest_days: list[int] = Field(default_factory=list)
    review_reserve_ratio: float = Field(0.25, ge=0, le=0.85)
    session_minutes: int = Field(50, ge=10, le=180)
    fairness_floor_ratio: float = Field(0.15, ge=0, le=0.8)
    max_sessions_per_day: int = Field(6, ge=1, le=24)


class ScheduleRequest(BaseModel):
    start_date: date
    horizon_days: int = Field(7, ge=1, le=60)
    subjects: list[SubjectIn]
    topics: list[TopicIn]
    exams: list[ExamIn] = []
    profile: ProfileIn = ProfileIn()
